# Python-project
Working with python program in creating databases in SQL . Data works
